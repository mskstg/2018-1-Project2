# -*- coding: utf-8 -*-
"""
Created on Thu May 10 22:27:00 2018

@author: HTG
"""

def readQueryFile(filename):
    query_dict = {}

    with open(filename, 'r') as f:
        text = f.read()
        queries = text.split('\n\n')
        for query in queries:
            br = query.find('\n')
       
    return query_dict

query_dict = readQueryFile('doc/query.txt')

query_dict